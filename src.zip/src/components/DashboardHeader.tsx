// components/DashboardHeader.tsx
'use client';

import {
  Container,
  Flex,
  Group,
  Box,
  Text,
  ActionIcon,
  Tooltip,
  Menu,
  Avatar,
  Burger,
  ThemeIcon,
  useMantineColorScheme,
} from '@mantine/core';
import {
  IconNetwork,
  IconSettings,
  IconSun,
  IconMoon,
  IconUser,
  IconLogout,
} from '@tabler/icons-react';

interface DashboardHeaderProps {
  sidebarOpened: boolean;
  onToggleSidebar: () => void;
  mounted: boolean;
}

export function DashboardHeader({ 
  sidebarOpened, 
  onToggleSidebar, 
  mounted 
}: DashboardHeaderProps) {
  const { colorScheme, toggleColorScheme } = useMantineColorScheme();
  const dark = mounted ? colorScheme === 'dark' : false;

  if (!mounted) {
    return (
      <Container fluid h="100%" px="xl">
        <Flex h="100%" justify="space-between" align="center">
          <Group gap="md">
            <Burger opened={false} onClick={() => {}} size="sm" />
            <Group gap="xs">
              <ThemeIcon
                variant="gradient"
                gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
                size="lg"
                radius="md"
              >
                <IconNetwork size={20} />
              </ThemeIcon>
              <Box>
                <Text 
                  fw={800} 
                  size="xl" 
                  variant="gradient"
                  gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
                >
                  mySRE
                </Text>
                <Text size="xs" c="dimmed">Knowledge Visualization Platform</Text>
              </Box>
            </Group>
          </Group>
          <Group gap="sm">
            <ActionIcon variant="light" color="blue" size="lg" radius="md" disabled>
              <IconMoon size={18} />
            </ActionIcon>
          </Group>
        </Flex>
      </Container>
    );
  }

  return (
    <Container fluid h="100%" px="xl">
      <Flex h="100%" justify="space-between" align="center">
        <Group gap="md">
          <Burger
            opened={sidebarOpened}
            onClick={onToggleSidebar}
            size="sm"
          />
          <Group gap="xs">
            <ThemeIcon
              variant="gradient"
              gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
              size="lg"
              radius="md"
            >
              <IconNetwork size={20} />
            </ThemeIcon>
            <Box>
              <Text 
                fw={800} 
                size="xl" 
                variant="gradient"
                gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
              >
                mySRE
              </Text>
              <Text size="xs" c="dimmed">Knowledge Visualization Platform</Text>
            </Box>
          </Group>
        </Group>

        <Group gap="sm">
          <Tooltip label={dark ? 'Light mode' : 'Dark mode'}>
            <ActionIcon
              variant="light"
              color={dark ? 'yellow' : 'blue'}
              onClick={toggleColorScheme}
              size="lg"
              radius="md"
            >
              {dark ? <IconSun size={18} /> : <IconMoon size={18} />}
            </ActionIcon>
          </Tooltip>

          <Tooltip label="Settings">
            <ActionIcon variant="light" color="gray" size="lg">
              <IconSettings size={18} />
            </ActionIcon>
          </Tooltip>
          
          <Menu shadow="lg" width={220} position="bottom-end" offset={10}>
            <Menu.Target>
              <ActionIcon variant="light" size="lg" radius="xl">
                <Avatar
                  size="sm"
                  radius="xl"
                  variant="gradient"
                  gradient={{ from: 'blue', to: 'cyan', deg: 45 }}
                  style={{ cursor: 'pointer' }}
                >
                  <IconUser size={16} />
                </Avatar>
              </ActionIcon>
            </Menu.Target>

            <Menu.Dropdown>
              <Menu.Label>
                <Group gap="xs">
                  <Avatar size="xs" color="blue">U</Avatar>
                  <Text size="sm">Signed in as</Text>
                </Group>
              </Menu.Label>
              <Menu.Item>
                <Text size="sm" fw={600}>Researcher User</Text>
                <Text size="xs" c="dimmed">researcher@example.com</Text>
              </Menu.Item>
              <Menu.Divider />
              <Menu.Item 
                leftSection={<IconLogout size={16} />}
                color="red" 
                onClick={() => console.log('Logout clicked')}
              >
                Sign out
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>
      </Flex>
    </Container>
  );
}